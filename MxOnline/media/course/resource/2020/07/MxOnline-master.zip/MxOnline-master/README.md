
# MxOnline
在线在线教育平台
## MyBlog
博客里面有这个项目的详细教程
[点此进入我的博客](http://www.cnblogs.com/derek1184405959/)<br /> 
## 环境
python: 3.6.4<br /> 
Django: 2.0.2
### MxOnline/resourses
[初始前端文件](https://pan.baidu.com/s/194dXX1vFlsUc2k6WZwLUwQ)
### xadmin下载地址
[点击下载](https://github.com/sshwsfc/xadmin/tree/django2)<br /> 
### 富文本编辑器Ueditor下载地址
[点击下载](https://github.com/twz915/DjangoUeditor3/)<br /> 

### 温馨提醒
如果想播放视频，格式一定要正确，我给一个视频链接做测试用吧！</br>
http://p96dsgm7r.bkt.clouddn.com/%E7%AC%AC%E4%B8%80%E7%AB%A0~2.mp4</br>
把上面链接复制到视频--“访问地址” 里面就可以播放了。

